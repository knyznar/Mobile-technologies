package com.example.android_course_lab4

class ListElement(val description : String, val image: Int){

}